﻿using System;

[Serializable]
public class PayPalExecutePaymentJsonRequest {

	public string payer_id;

}