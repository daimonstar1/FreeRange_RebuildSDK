﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
namespace GameTacoSDK
{
    public enum AnchorPresets
    {
        TopLeft,
        TopCenter,
        TopRight,

        MiddleLeft,
        MiddleCenter,
        MiddleRight,

        BottomLeft,
        BottonCenter,
        BottomRight,
        BottomStretch,

        VertStretchLeft,
        VertStretchRight,
        VertStretchCenter,

        HorStretchTop,
        HorStretchMiddle,
        HorStretchBottom,

        StretchAll
    }

    public enum PivotPresets
    {
        TopLeft,
        TopCenter,
        TopRight,

        MiddleLeft,
        MiddleCenter,
        MiddleRight,

        BottomLeft,
        BottomCenter,
        BottomRight,
    }
    public class View : MonoBehaviour
    {
        private Dictionary<eNumComponentType, TacoUIButtonView> buttons;
        private Dictionary<eNumComponentType, TacoUIInputView> inputs;
        private Transform canvas;
        public delegate void ButtonClicked(Button sender, TacoUIButtonEventArgs args);
        public delegate void InputFiledChanged(InputField sender, TacoUIInputEventArgs args);
        public event ButtonClicked _buttonClicked;
        public event InputFiledChanged _textChanged;
        public void addButton(eNumComponentType type, TacoUIButtonView button)
        {
            if (buttons == null)
                buttons = new Dictionary<eNumComponentType, TacoUIButtonView>();
            if (buttons.ContainsKey(type))
                return;
            button.type = type;
            button.on_click +=buttonClicked;
            buttons.Add(type, button);
        }
        protected virtual void buttonClicked(Button sender, TacoUIButtonEventArgs args)
        {
               _buttonClicked?.Invoke(sender, args);
        }
        public TacoUIButtonView getButton(eNumComponentType type)
        {
            if (!buttons.ContainsKey(type))
            {
                Debug.LogError("Type=" + type.ToString() + " not exist in dictionary");
                return null;
            }
            return buttons[type];
        }
        public void addInputField(eNumComponentType type, TacoUIInputView inputfield)
        {
            if (inputs == null)
                inputs = new Dictionary<eNumComponentType, TacoUIInputView>();
            if (inputs.ContainsKey(type))
                return;
            inputfield.type = type;
            inputfield.data_changed += textChanged;
            inputs.Add(type, inputfield);
        }
        protected virtual void textChanged(InputField sender, TacoUIInputEventArgs args)
        {
            _textChanged?.Invoke(sender, args);
        }
        public TacoUIInputView getInputField(eNumComponentType type)
        {
            if (!inputs.ContainsKey(type))
            {
                Debug.LogError("Type=" + type.ToString() + " not exist in dictionary");
                return null;
            }
            return inputs[type];
        }
        public Transform findRootCanvas()
        {
            if (canvas != null)
                return canvas;
            canvas = FindObjectOfType<Canvas>().transform;
            if (canvas == null)
                Debug.LogError("canvas is null");
            return canvas;
        }
        /// <summary>
        /// Set original prefabs in midle anchor and set x,y,z,width,height=0
        /// </summary>
        /// <param name="source"></param>
        /// <param name="allign"></param>
        /// <param name="offsetX"></param>
        /// <param name="offsetY"></param>
        public static void SetAnchor(RectTransform source, AnchorPresets allign, int offsetX = 0, int offsetY = 0)
        {
            source.anchoredPosition = new Vector3(offsetX, offsetY, 0);

            switch (allign)
            {
                case (AnchorPresets.TopLeft):
                    {
                        source.anchorMin = new Vector2(0, 1);
                        source.anchorMax = new Vector2(0, 1);
                        break;
                    }
                case (AnchorPresets.TopCenter):
                    {
                        source.anchorMin = new Vector2(0.5f, 1);
                        source.anchorMax = new Vector2(0.5f, 1);
                        break;
                    }
                case (AnchorPresets.TopRight):
                    {
                        source.anchorMin = new Vector2(1, 1);
                        source.anchorMax = new Vector2(1, 1);
                        break;
                    }

                case (AnchorPresets.MiddleLeft):
                    {
                        source.anchorMin = new Vector2(0, 0.5f);
                        source.anchorMax = new Vector2(0, 0.5f);
                        break;
                    }
                case (AnchorPresets.MiddleCenter):
                    {
                        source.anchorMin = new Vector2(0.5f, 0.5f);
                        source.anchorMax = new Vector2(0.5f, 0.5f);
                        break;
                    }
                case (AnchorPresets.MiddleRight):
                    {
                        source.anchorMin = new Vector2(1, 0.5f);
                        source.anchorMax = new Vector2(1, 0.5f);
                        break;
                    }

                case (AnchorPresets.BottomLeft):
                    {
                        source.anchorMin = new Vector2(0, 0);
                        source.anchorMax = new Vector2(0, 0);
                        break;
                    }
                case (AnchorPresets.BottonCenter):
                    {
                        source.anchorMin = new Vector2(0.5f, 0);
                        source.anchorMax = new Vector2(0.5f, 0);
                        break;
                    }
                case (AnchorPresets.BottomRight):
                    {
                        source.anchorMin = new Vector2(1, 0);
                        source.anchorMax = new Vector2(1, 0);
                        break;
                    }

                case (AnchorPresets.HorStretchTop):
                    {
                        source.anchorMin = new Vector2(0, 1);
                        source.anchorMax = new Vector2(1, 1);
                        break;
                    }
                case (AnchorPresets.HorStretchMiddle):
                    {
                        source.anchorMin = new Vector2(0, 0.5f);
                        source.anchorMax = new Vector2(1, 0.5f);
                        break;
                    }
                case (AnchorPresets.HorStretchBottom):
                    {
                        source.anchorMin = new Vector2(0, 0);
                        source.anchorMax = new Vector2(1, 0);
                        break;
                    }

                case (AnchorPresets.VertStretchLeft):
                    {
                        source.anchorMin = new Vector2(0, 0);
                        source.anchorMax = new Vector2(0, 1);
                        break;
                    }
                case (AnchorPresets.VertStretchCenter):
                    {
                        source.anchorMin = new Vector2(0.5f, 0);
                        source.anchorMax = new Vector2(0.5f, 1);
                        break;
                    }
                case (AnchorPresets.VertStretchRight):
                    {
                        source.anchorMin = new Vector2(1, 0);
                        source.anchorMax = new Vector2(1, 1);
                        break;
                    }

                case (AnchorPresets.StretchAll):
                    {
                        source.anchorMin = new Vector2(0, 0);
                        source.anchorMax = new Vector2(1, 1);
                        break;
                    }
            }
        }

        public static void SetPivot(RectTransform source, PivotPresets preset)
        {

            switch (preset)
            {
                case (PivotPresets.TopLeft):
                    {
                        source.pivot = new Vector2(0, 1);
                        break;
                    }
                case (PivotPresets.TopCenter):
                    {
                        source.pivot = new Vector2(0.5f, 1);
                        break;
                    }
                case (PivotPresets.TopRight):
                    {
                        source.pivot = new Vector2(1, 1);
                        break;
                    }

                case (PivotPresets.MiddleLeft):
                    {
                        source.pivot = new Vector2(0, 0.5f);
                        break;
                    }
                case (PivotPresets.MiddleCenter):
                    {
                        source.pivot = new Vector2(0.5f, 0.5f);
                        break;
                    }
                case (PivotPresets.MiddleRight):
                    {
                        source.pivot = new Vector2(1, 0.5f);
                        break;
                    }

                case (PivotPresets.BottomLeft):
                    {
                        source.pivot = new Vector2(0, 0);
                        break;
                    }
                case (PivotPresets.BottomCenter):
                    {
                        source.pivot = new Vector2(0.5f, 0);
                        break;
                    }
                case (PivotPresets.BottomRight):
                    {
                        source.pivot = new Vector2(1, 0);
                        break;
                    }
            }
        }
    }
}
